package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.OneDFOperator

import org.apache.spark.{SparkConf, SparkContext}

class OneDFOperator() {

  def inside(x: Int, y: Int, z: Int): Boolean = {
    x * x + y * y < z * z
  }

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
      val data1 = sc.parallelize(Array(data(i))).map(l=>l)
      sc.stop()
    }
  }
}

