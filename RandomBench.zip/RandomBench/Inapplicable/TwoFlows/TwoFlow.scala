package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.TwoFlows

import org.apache.spark.{SparkConf, SparkContext}

class TwoFlow() {

  def inside(x: Int, y: Int, z: Int): Boolean = {
    x * x + y * y < z * z
  }

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
      val data1 = sc.parallelize(Array(data(i))).map {
        s =>
          val cols = s.split(",")
          (cols(0), Integer.parseInt(cols(1)), Integer.parseInt(cols(2)))
      }.filter( s => s._1.equals("90024"))


      val pair = data1.map {
        s =>
          if (s._2 >= 40 & s._2 <= 65) {
            ("40-65", s._3)
          } else if (s._2 >= 20 & s._2 < 40) {
            ("20-39", s._3)
          } else if (s._2 < 20) {
            ("0-19", s._3)
          } else {
            (">65", s._3 / 0)
          }
      }

      sc.stop()
    }
  }
}

