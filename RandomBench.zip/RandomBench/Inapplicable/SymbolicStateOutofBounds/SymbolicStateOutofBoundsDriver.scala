package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.SymbolicStateOutofBounds

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class SymbolicStateOutofBoundsDriver{
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new SymbolicStateOutofBounds()
    obj.wdCount(args)
  }
}


