package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.SymbolicStateOutofBounds

import org.apache.spark.{SparkConf, SparkContext}

class SymbolicStateOutofBounds() {

  def inside(x: Int, y: Int, z: Int): Boolean = {
    x * x + y * y < z * z
  }

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
      val data1 = sc.parallelize(Array(data(i))).map{ s =>
        val cols = s.split(",")
        Integer.parseInt(cols(1))
      }.map{ l=>
        var dis = 1
        var tmp = l

        if(l <= 0){
          dis = 0
        }else {
          while (tmp != 1) {
            if (tmp % 2 == 0) {
              tmp = tmp / 2
            } else {
              tmp = 3 * tmp + 1
            }
            dis = dis + 1
          }
        }
        (l, dis)
      }//.foreach(println)
        .filter(m => m._2.equals(25))

      sc.stop()
    }
  }
}

