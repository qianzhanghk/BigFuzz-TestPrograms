package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.ExternalUDF

import org.apache.spark.{SparkConf, SparkContext}

class ExternalUDF() {

  def inside(x: Int, y: Int, z: Int): Boolean = {
    x * x + y * y < z * z
  }

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
      val data1 = sc.parallelize(Array(data(i))).map {
        s =>
          val cols = s.split(",")
          (Integer.parseInt(cols(0)), Integer.parseInt(cols(1)), Integer.parseInt(cols(2)))
      }.filter(s => inside(s._1, s._2, s._3))


      print(data1.count())
      sc.stop()
    }
  }
}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

