package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.ExternalUDF

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class ExternalUDFDriver{
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new ExternalUDF()
    obj.wdCount(args)
  }
}


