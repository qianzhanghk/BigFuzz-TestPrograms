package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.Property

import org.apache.spark.{SparkConf, SparkContext}

class Property() {

  def inside(x: Int, y: Int, z: Int): Boolean = {
    x * x + y * y < z * z
  }

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
      val data1 = sc.parallelize(Array(data(i))).map{ s=>
        val a = s.split(",")
        (a(2).toFloat,Integer.parseInt(a(3)),a(4).toFloat,a(6))
      }.map{s=>
        var a = s._1
        var i=1-1
        while (i<s._2){
          i=i+1
          a = a *(1+s._3)
        }
        (a,s._2,s._3,s._4)
      }

      sc.stop()
    }
  }
}

