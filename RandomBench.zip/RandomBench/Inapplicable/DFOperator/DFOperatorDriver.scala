package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.DFOperator

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class DFOperatorDriver{
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new DFOperator()
    obj.wdCount(args)
  }
}


