package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.Inapplicable.OutofJDU

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class OutofJDUDriver{
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new OutofJDU()
    obj.wdCount(args)
  }
}


