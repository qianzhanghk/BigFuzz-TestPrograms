package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.StudentGrades

import org.apache.spark.{SparkConf, SparkContext}

import scala.math.log10

class StudentGrade() {

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {

      val map1 = sc.parallelize(Array(data(i))).flatMap{ line =>
        val arr = line.split(",")
        arr
      }
        .map{  s =>
          val a = s.split(":")
          (a(0) , a(1).toInt)
        }
        .map { a =>
          if (a._2 > 40)
            (a._1 + " Pass", 1)
          else
            (a._1 + " Fail", 1)
        }
        .reduceByKey(_ + _)
        .filter(v => v._2 > 1)
        .collect
        .foreach(println)
    }
    sc.stop()
  }
}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

