package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.StudentGrades

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class StudentGradeDriver {
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new StudentGrade()
    obj.wdCount(args)
  }
}


