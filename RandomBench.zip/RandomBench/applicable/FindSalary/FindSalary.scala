package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.FindSalary

import org.apache.spark.{SparkConf, SparkContext}

class FindSalary() {

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {

      val map1 = sc.parallelize(Array(data(i))).map {
        line =>
          if (line.substring(0, 1).equals("$")) {
            var i = line.substring(1, 6)
            i
          } else {
            line
          }
      }
        .map(p => Integer.parseInt(p))
        .filter(r => r < 300)
        .reduce(_ + _)
    }
    sc.stop()

  }
}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

