package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.CommuteType

import org.apache.spark.{SparkConf, SparkContext}

import scala.math.log10

class CommuteType() {

  def wdCount(data1: Array[String], data2:Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Commute")

    val startTime = System.currentTimeMillis();
    val sc = new SparkContext(conf)

    val trips = sc.parallelize(data1)
      .map { line1 =>
        val cols = line1.split(",")
        (cols(1), Integer.parseInt(cols(3)) / Integer.parseInt(cols(4)))
      }
    val locations = sc.textFile(
      "/home/qzhang/Programs/eclipse/Test-Minimization-in-Big-Data-JPF-integrated/workspace/up_jpf/benchmarks/src/datasets/zipcode/*")
      .map { line2 =>
        val cols = line2.split(",")
        (cols(0), cols(1))
      }
      .filter{v =>
        val t1 = v._1
        val t2 = v._2
        t2.equals("Palms")}
    val joined = trips.join(locations)
    joined
      .map { s =>
        // Checking if speed is < 25mi/hr
        if (log10(s._2._1) > 40) {
          ("car", 1)
        } else if (log10(s._2._1) > 15) {
          ("public", 1)
        } else {
          ("walk", 1)
        }
      }
      .reduceByKey(_ + _)
    println("Job Finished")

    println("Time: " + (System.currentTimeMillis() - startTime))
    sc.stop()
  }

}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

