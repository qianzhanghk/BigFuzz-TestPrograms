package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.CommuteType

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith


@RunWith(classOf[JQF])
class CommuteTypeDriver {
  @Fuzz
  def test(args1: Array[String],args2: Array[String]): Unit = {
    val obj = new CommuteType()
    obj.wdCount(args1,args2)
  }
}


