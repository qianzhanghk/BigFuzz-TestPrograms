package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.WordCountEXF

import edu.berkeley.cs.jqf.fuzz.{Fuzz, JQF}
import org.junit.runner.RunWith



@RunWith(classOf[JQF])
class WordCountExFDriver{
  @Fuzz
  def test(args: Array[String]): Unit = {
    val obj = new WordCountExF()
    obj.wdCount(args)
  }
}


