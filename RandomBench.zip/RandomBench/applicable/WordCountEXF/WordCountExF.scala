package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.WordCountEXF

import org.apache.spark.{SparkConf, SparkContext}

import scala.math.log10

class WordCountExF(){

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {
    val wordCounts = sc.parallelize(Array(data(i))).flatMap(line => line.split(","))
      .map(s => (s,1))
      .reduceByKey(_+_)
      .filter{ v =>
        val v1 = log10(v._2)
        v1 > 1
      }
      wordCounts.foreach(println)
    }
    sc.stop()
  }
}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

