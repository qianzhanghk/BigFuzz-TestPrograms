package edu.ucla.cs.bigfuzz.sparkprogram.RandomBench.applicable.MovieRating

import org.apache.spark.{SparkConf, SparkContext}

class MovieRating() {

  def wdCount(data: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local")
    conf.setAppName("Student")
    val sc = new SparkContext(conf)

    //val textFile = sc.textFile("README.md")

    for (i <- 0 to data.length - 1) {

      val map1 = sc.parallelize(Array(data(i))).map { line =>
        val arr = line.split(":")
        val movie_str = arr(0)
        val ratings = arr(1).split(",")(0).split("_")(1)
        (movie_str, ratings.substring(0, 1))
      }
        .map { c =>
          val str = c._1
          (str, Integer.parseInt(c._2))
        }
        .filter { b =>
          val t1 = b._1
          val t2 = b._2
          t2 > 4
        }.reduceByKey(_ + _).collect().foreach(println)
    }
    sc.stop()

  }
}


/***
Big Test Conf
filter1 > "",1
map3> "",1
map4 > "CS:123"
reduceByKey2 > {1,2,3,4}
flatMap5 > "a,a"
DAG >filter1-reduceByKey2:reduceByKey2-map3:map3-map4:map4-flatMap5
  */

